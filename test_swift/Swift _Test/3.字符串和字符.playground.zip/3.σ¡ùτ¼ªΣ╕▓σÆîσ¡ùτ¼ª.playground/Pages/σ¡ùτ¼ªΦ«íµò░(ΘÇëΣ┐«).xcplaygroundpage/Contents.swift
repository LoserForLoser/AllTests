//: 字符计数: 使用字符串characters属性的count属性来获取字符个数.
let c = "小波说雨燕abc!!!"
c.characters.count

//: [修改字符串-索引](@next)
