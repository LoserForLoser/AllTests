//: 连接字符串和字符
//: - 用 + 
let a = "洪荒"
let b = "少女"
let c = "傅园慧"

var famous = a + b + c



//: - 向字符串添加字符, 用append方法
let number: Character = "1️⃣"

famous.append(number)



//: [>](@next)
