//: 字符
//:  - 用Character类型来定义字符串.
var a: Character = "我"
var b: Character = "波"
//:  - 可以对一个字符串的characters属性进行循环,来访问其中单个字符.
let words = "小波说雨燕"


for word in words.characters {
    print(word)
}



//: [>](@next)
