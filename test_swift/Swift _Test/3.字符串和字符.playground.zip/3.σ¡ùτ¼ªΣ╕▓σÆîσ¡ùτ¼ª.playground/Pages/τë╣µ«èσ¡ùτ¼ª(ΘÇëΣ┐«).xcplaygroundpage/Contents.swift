//: 特殊字符: \0 \\ \t \n \r \" \' \u{n}
let a = "Hello World"
print(a)

//: - Unicode: 一种国际化文字编码标准. 几乎可以兼容所有语言的文字和书写系统.除了可以直接打出Unicode字符,还可以使用数字化的量,叫Unicode标量.\u{1F425} [汉字Unicode一览](http://www.asahi-net.or.jp/~ax2s-kmtn/ref/unicode/cjku_klist.html)
"\u{515c}"
"\u{4e8b}"



//: [>](@next)
