//: ----
//:  - [小波说雨燕 3天学会Swift 3](http://www.xiaoboswift.com)
//:  - 全集课件：[github.com/yagamis](http://github.com/yagamis/swift2basic)
//: ----
//: 字符串和字符
//:
//: ----
//:
//:  - 字符串是有序的字符集合,或者叫文本.如"我已经使用了洪荒之力".
//:  - String是字符串类型,Character是字符类型.
//:  - 2个字符串可以通过 + 来连接.
//:  - 💡通过字符串插值可合成一个长字符串.
//:
//: ----
//:
//:  [>](@next)
