import UIKit

public func 坐标图1() -> UIImage? {
    return UIImage(named: "coordinate")
}

public func 坐标图2() -> UIImage? {
    return UIImage(named: "coordinate-2")
}
