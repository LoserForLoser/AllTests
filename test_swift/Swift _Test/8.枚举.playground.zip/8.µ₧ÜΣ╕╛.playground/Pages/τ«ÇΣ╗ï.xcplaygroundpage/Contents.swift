//: ----
//:  - 小波说雨燕 3天学会Swift 3
//:  - 全集课件：[github.com/yagamis](http://github.com/yagamis/swift2basic)
//: ----
//: 枚举 enumeration
//:
//: ----
//:  - 计数、列举（有限的情况）；详细叙述之意。“增强的、更抽象型“的数字类型。
//:  - 非常强大，与switch语句结合使用，天生一对。
//: ----
//:


//:  [定义和使用](@next)
