import UIKit

public func demo() -> UIImage?{
    return UIImage(named: "CollectionTypes_intro_2x")
}
