//: 字符串插值:组合常量/变量/字面量/表达式成一个长字符串
let name = "小波"
let type = "G"
let number = 11
let price = 158.5

let 订票提示 = "\(name)先生, 您订购了\(type)\(number)的往返票,需支付\(price * 2)元."


//: [>](@next)
