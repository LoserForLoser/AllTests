import Foundation

import UIKit


public func setdemo() -> UIImage? {
    return UIImage(named: "setVennDiagram_2x")
}

public func setRelation() -> UIImage? {
    return UIImage(named: "setEulerDiagram_2x")
}
