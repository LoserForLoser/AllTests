//: ----
//:  - 小波说雨燕 3天学会Swift 3
//:  - 全集课件：[github.com/yagamis](http://github.com/yagamis/swift2basic)
//: ----

//: 集合类型
//:
//: ----
//:  - 一组同类型的值的组合, 根据组合的整体特性分为:
//:  - 有序可重复 - 数组(Array)
//:  - 无序不重复 - Set
//:  - 无序可重复,但每个值有唯一的键(Key) - 字典(Dictionary)
//:  - ☆批量处理集合中的元素, 可以使用 for in循环

demo()


//:  [数组>](@next)
